import React from "react";

function Repo() {
  return <article className="repo"></article>;
}

export default Repo;
